﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using VioletsLoops.Models;

namespace VioletsLoops.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult FAQ()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Tools() 
        {
            HttpContext.Session.SetString("FirstName", "Violet");
            HttpContext.Session.SetString("LastName", "Simon");
            HttpContext.Session.SetString("Course", "IT2030");
            HttpContext.Session.SetInt32("FavNum", 88); 

            return View(new MySession());
        }

        [HttpPost]
        public IActionResult Tools(MySession session)
        {
            HttpContext.Session.SetString("FirstName", session.FirstName);
            HttpContext.Session.SetString("LastName", session.LastName);
            HttpContext.Session.SetString("Course", session.Course);
            HttpContext.Session.SetInt32("FavNum", session.FavNum);

            return RedirectToAction(nameof(Tools));
        }

        [HttpGet]
        public IActionResult DisplaySession()
        {
            string firstName = HttpContext.Session.GetString("FirstName");
            string lastName = HttpContext.Session.GetString("LastName");
            string course = HttpContext.Session.GetString("Course");
            int favNum = (int)HttpContext.Session.GetInt32("FavNum");

            MySession session = new MySession
            {
                FirstName = firstName,
                LastName = lastName,
                Course = course,
                FavNum = favNum
            };

            return View("Tools", session);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}