﻿using System;
using System.Collections.Generic;
namespace VioletsLoops.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts() 
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel {
                    ProductId = 1,
                    ProductName = "Granny Triangle Bandana",
                    ProductDescription = "Accessories",
                    ProductImage = "/Images/bandana.jpg",
                    ProductPrice = 22
                },

                new ProductModel {
                    ProductId = 2,
                    ProductName = "Baphomet Plushie",
                    ProductDescription = "Plushie",
                    ProductImage = "/Images/baphomet.jpg",
                    ProductPrice = 30
                },

                new ProductModel {
                    ProductId = 3,
                    ProductName = "Granny Square Cardigan",
                    ProductDescription = "Clothing",
                    ProductImage = "/Images/cardigan.jpg",
                    ProductPrice = 75
                },

                new ProductModel {
                    ProductId= 4,
                    ProductName = "Cat Heart Plushie",
                    ProductDescription = "Plushie",
                    ProductImage = "/Images/cat.jpg",
                    ProductPrice = 35
                },

                new ProductModel {
                    ProductId = 5,
                    ProductName = "Velvet Cow Plushie",
                    ProductDescription = "Plushie",
                    ProductImage = "/Images/cow.jpg",
                    ProductPrice = 35
                },

                new ProductModel {
                    ProductId = 6,
                    ProductName = "Korok Car Hanger",
                    ProductDescription = "Plushie",
                    ProductImage = "/Images/korok.jpg",
                    ProductPrice = 25
                }
            };

            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products) 
            {
                if (product.ProductId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }

    }
}
