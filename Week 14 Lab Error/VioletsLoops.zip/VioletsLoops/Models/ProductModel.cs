﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VioletsLoops.Models

{
    public class ProductModel
    {
        [Key]
        public int ProductId { get; set; }

        [Required(ErrorMessage = "Please enter a valid product name.")]
        public string ProductName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a valid description.")]
        public string ProductDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please add an image.")]
        public string ProductImage { get; set; } = string.Empty;

        [Required]
        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }
    }
}
