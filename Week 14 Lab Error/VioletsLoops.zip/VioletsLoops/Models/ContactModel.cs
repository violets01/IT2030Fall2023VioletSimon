﻿using System.ComponentModel.DataAnnotations;

namespace VioletsLoops.Models
{
    public class ContactModel
    {
        [Required(ErrorMessage = "Please enter a first name.")]
        [StringLength(30, 
            ErrorMessage = "Name must be 30 characters or less.")]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,40}$",
            ErrorMessage = "Cannot contain special characters or numbers.")]
        public string? FirstName { get; set; }

        [Required(ErrorMessage = "Please enter a last name.")]
        [StringLength(30,
           ErrorMessage = "Name must be 30 characters or less.")]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,40}$",
           ErrorMessage = "Cannot contain special characters or numbers.")]
        public string? LastName { get; set; }

        [Required(ErrorMessage = "Please enter a valid address.")]
        public string? Address { get; set; }

        [Required(ErrorMessage = "Please enter a valid phone number.")]
        [RegularExpression(@"^[0-9]{10}$",
         ErrorMessage = "Please only include your 10 diget long phone number.")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Please enter a valid email address.")]
        [EmailAddress]
        public string? Email { get; set; }

        [Required(ErrorMessage = "Please tell us how we can help you.")]
        public string? Message { get; set; }

        [Key]
        public int ContactId {  get; set; }
    }
}
