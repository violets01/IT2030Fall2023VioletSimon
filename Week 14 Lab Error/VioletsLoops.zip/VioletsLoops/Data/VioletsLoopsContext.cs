﻿using Microsoft.EntityFrameworkCore;
using VioletsLoops.Models;

namespace VioletsLoops.Data
{
    public class VioletsLoopsContext : DbContext 
    {
        public VioletsLoopsContext (DbContextOptions<VioletsLoopsContext> options)
        : base(options)
        { }
        public DbSet<ProductModel> ProductDb { get; set; }
        public DbSet<ContactModel> ContactDb { get; set; } 
    }
}
